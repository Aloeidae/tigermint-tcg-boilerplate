# Sticker League — a Pokémon-style TCG for the Tigermint boilerplate

Telegram's trending sticker packs as fighters. Pokémon TCG mechanics, Telegram
vocabulary, generated to a balance curve, plugged into
https://github.com/Aloeidae/tigermint-tcg-boilerplate.

```
RULESET.md                 the complete rules (players + engine authors)
ENGINE_INTEGRATION.md      gap analysis + port plan for the boilerplate, effect DSL
engine/types.sticker.ts    TS types matching cards.json; rules presets; cost coverage
schema/card.schema.json    JSON Schema for out/cards.json entries
data/roster.csv            the 150 sticker packs (rank, character, link, type, role)
data/types.json            reaction types + weakness wheel
data/move_templates.json   move pool per type (cost / price / effects)
data/traits.json           passive abilities
data/trainers.json         Bots, Admins, Channels, Gifts, Reactions (hand-authored)
data/overrides.json        per-card designer overrides (applied last)
scripts/generate_cards.py  roster + templates -> out/
scripts/fetch_featured_stickers.py  pull Telegram's live trending list into the roster
out/cards.json             canonical set (200 Stickers + 51 trainer/reaction cards)
out/pack.json              boilerplate manifest — copy to packages/client/public/pack/
out/nft_attributes.json    TigerMint / NFT attribute arrays per card
out/starter_decks.json     eight mono-type Quick decks
out/balance_report.md      distributions + rule-check flags
```

## Workflow

1. `python3 scripts/fetch_featured_stickers.py` (needs Telegram api_id/hash) —
   or fill `data/roster.csv` by hand. Ranks 1–6 are seeded from your brief.
2. `python3 scripts/generate_cards.py` — regenerates everything under `out/`.
   Read `out/balance_report.md`; every flag is a rule from RULESET §12.
3. Polish names/flavor with an LLM into `data/overrides.json`, re-run step 2.
4. Drop `out/pack.json` + art into `packages/client/public/pack/` — it plays
   in the untouched boilerplate today through the `legacy` mapping.
5. Port the engine following ENGINE_INTEGRATION.md; the `game` block on every
   pack card is the full Sticker League definition.

#!/usr/bin/env python3
"""
Fill data/roster.csv with Telegram's real Trending ("featured") sticker sets.

The trending list is only exposed through Telegram's MTProto API
(messages.getFeaturedStickers / getOldFeaturedStickers), so this needs a
user session — not a bot token. Get api_id/api_hash at https://my.telegram.org.

    pip install telethon
    export TG_API_ID=123456 TG_API_HASH=abcdef...
    python3 scripts/fetch_featured_stickers.py            # fill placeholder rows
    python3 scripts/fetch_featured_stickers.py --overwrite  # rank 1..150 = live list
    python3 scripts/fetch_featured_stickers.py --verify --bot-token 123:ABC  # check links via Bot API

Rows with placeholder=0 (your hand-picked characters) are kept unless
--overwrite is given. Type/role columns are preserved so re-generating cards
keeps the type distribution stable. Character names are derived from the set
title; edit them by hand afterwards if you want a shorter nickname.
"""
from __future__ import annotations

import argparse
import asyncio
import csv
import json
import os
import re
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ROSTER = ROOT / "data" / "roster.csv"
FIELDS = ["rank", "character", "pack_title", "pack_short_name", "pack_url", "type", "role", "placeholder", "verified", "notes"]


def character_from_title(title: str) -> str:
    t = re.sub(r"(?i)\b(stickers?|sticker pack|pack|by .+|animated|premium|official)\b", "", title)
    t = re.sub(r"[^\w\s'&-]", "", t).strip()
    return t.title() if t else title


async def fetch_featured(limit: int) -> list[dict]:
    from telethon import TelegramClient  # type: ignore
    from telethon.tl.functions.messages import GetFeaturedStickersRequest, GetOldFeaturedStickersRequest  # type: ignore

    api_id = int(os.environ["TG_API_ID"])
    api_hash = os.environ["TG_API_HASH"]
    client = TelegramClient(str(ROOT / ".tg_session"), api_id, api_hash)
    await client.start()
    out: list[dict] = []
    seen = set()

    def add(covered):
        s = covered.set
        if s.short_name in seen:
            return
        seen.add(s.short_name)
        out.append({
            "title": s.title, "short_name": s.short_name, "count": s.count,
            "animated": bool(getattr(s, "animated", False)), "video": bool(getattr(s, "videos", False)),
            "emojis": bool(getattr(s, "emojis", False)),
        })

    res = await client(GetFeaturedStickersRequest(hash=0))
    for c in res.sets:
        add(c)
    offset = 0
    while len(out) < limit:
        old = await client(GetOldFeaturedStickersRequest(offset=offset, limit=100, hash=0))
        if not old.sets:
            break
        for c in old.sets:
            add(c)
        offset += len(old.sets)
    await client.disconnect()
    # Skip custom-emoji sets; they are not sticker characters.
    return [s for s in out if not s["emojis"]][:limit]


def verify_bot_api(token: str, short_name: str) -> bool:
    url = f"https://api.telegram.org/bot{token}/getStickerSet?name={urllib.request.quote(short_name)}"
    try:
        with urllib.request.urlopen(url, timeout=15) as r:
            return bool(json.load(r).get("ok"))
    except Exception:
        return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=150)
    ap.add_argument("--overwrite", action="store_true", help="replace every row, rank = live trending position")
    ap.add_argument("--verify", action="store_true", help="verify short names via Bot API instead of fetching")
    ap.add_argument("--bot-token", default=os.environ.get("TG_BOT_TOKEN"))
    args = ap.parse_args()

    with open(ROSTER, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    if args.verify:
        if not args.bot_token:
            sys.exit("--verify needs --bot-token or TG_BOT_TOKEN")
        for r in rows:
            if r["pack_short_name"]:
                ok = verify_bot_api(args.bot_token, r["pack_short_name"])
                r["verified"] = "1" if ok else "0"
                print(f"{r['rank']:>3} {r['pack_short_name']:30} {'OK' if ok else 'NOT FOUND'}")
    else:
        sets = asyncio.run(fetch_featured(args.limit))
        print(f"fetched {len(sets)} featured sets")
        existing = {r["pack_short_name"] for r in rows if r["pack_short_name"]}
        queue = [s for s in sets if s["short_name"] not in existing] if not args.overwrite else sets
        targets = rows if args.overwrite else [r for r in rows if r.get("placeholder") == "1"]
        for r, s in zip(targets, queue):
            r.update({
                "character": character_from_title(s["title"]),
                "pack_title": s["title"],
                "pack_short_name": s["short_name"],
                "pack_url": f"https://t.me/addstickers/{s['short_name']}",
                "placeholder": "0",
                "verified": "1",
                "notes": f"featured; {s['count']} stickers; animated={s['animated']} video={s['video']}",
            })
        print(f"filled {min(len(targets), len(queue))} rows")

    with open(ROSTER, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows)
    print(f"wrote {ROSTER}. Now run: python3 scripts/generate_cards.py")


if __name__ == "__main__":
    main()
